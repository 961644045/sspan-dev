1：前往用户中心查看App Store账号，国区App Store已下架)

![](/images/c_ios_1.jpg)

2：打开App Store 切换账号，并下载App

![](/images/c_ios_2.jpg)

3：打开Safari，登录到 SSPANEL 的用户中心导入节点

![](/images/c_ios_3.jpg)

附加：iOS快速连接

![](/images/c_ios_4.jpg)