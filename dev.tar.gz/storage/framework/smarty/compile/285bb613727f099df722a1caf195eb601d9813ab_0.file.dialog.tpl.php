<?php
/* Smarty version 3.1.36, created on 2020-07-13 00:22:32
  from '/www/wwwroot/192.168.100.138/resources/views/material/dialog.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.36',
  'unifunc' => 'content_5f0b38c853eeb8_20933071',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '285bb613727f099df722a1caf195eb601d9813ab' => 
    array (
      0 => '/www/wwwroot/192.168.100.138/resources/views/material/dialog.tpl',
      1 => 1594570359,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f0b38c853eeb8_20933071 (Smarty_Internal_Template $_smarty_tpl) {
?><div aria-hidden="true" class="modal modal-va-middle fade" id="result" role="dialog" tabindex="-1">
    <div class="modal-dialog modal-xs">
        <div class="modal-content">
            <div class="modal-inner">
                <p class="h5 margin-top-sm text-black-hint" id="msg"></p>
            </div>
            <div class="modal-footer">
                <p class="text-right">
                    <button class="btn btn-flat btn-brand-accent waves-attach" data-dismiss="modal" type="button"
                            id="result_ok">知道了
                    </button>
                </p>
            </div>
        </div>
    </div>
</div><?php }
}
