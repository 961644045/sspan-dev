<?php
/* Smarty version 3.1.36, created on 2020-07-13 00:23:32
  from '/www/wwwroot/192.168.100.138/resources/views/material/table/js_1.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.36',
  'unifunc' => 'content_5f0b39047018f8_08179117',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '569344446854852d85c2091c57872cd7b6cbc5d9' => 
    array (
      0 => '/www/wwwroot/192.168.100.138/resources/views/material/table/js_1.tpl',
      1 => 1594570359,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f0b39047018f8_08179117 (Smarty_Internal_Template $_smarty_tpl) {
?>function modify_table_visible(id, key) {
if(document.getElementById(id).checked)
{
table_1.columns( '.' + key ).visible( true );
localStorage.setItem(window.location.href + '-haschecked-' + id, true);
}
else
{
table_1.columns( '.' + key ).visible( false );
localStorage.setItem(window.location.href + '-haschecked-' + id, false);
}
}
<?php }
}
