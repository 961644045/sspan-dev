<?php
/* Smarty version 3.1.36, created on 2020-07-13 00:23:32
  from '/www/wwwroot/192.168.100.138/resources/views/material/table/js_delete.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.36',
  'unifunc' => 'content_5f0b39047096e6_81735787',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '92f122800ba66273fc874bfebf3f657fbf12dc7f' => 
    array (
      0 => '/www/wwwroot/192.168.100.138/resources/views/material/table/js_delete.tpl',
      1 => 1594570359,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f0b39047096e6_81735787 (Smarty_Internal_Template $_smarty_tpl) {
?>table_1
.row('#row_1_' + deleteid)
.remove()
.draw();
<?php }
}
